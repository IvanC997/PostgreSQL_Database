--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "VideoKlubDB";
--
-- Name: VideoKlubDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "VideoKlubDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE "VideoKlubDB" OWNER TO postgres;

\connect "VideoKlubDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: VideoKlub; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "VideoKlub";


ALTER SCHEMA "VideoKlub" OWNER TO postgres;

--
-- Name: poslednji_unos(); Type: FUNCTION; Schema: VideoKlub; Owner: postgres
--

CREATE FUNCTION "VideoKlub".poslednji_unos() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
	NEW.poslednji_unos=current_timestamp;
	RETURN NEW;
END $$;


ALTER FUNCTION "VideoKlub".poslednji_unos() OWNER TO postgres;

--
-- Name: poslednji_unos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.poslednji_unos() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
	NEW.poslednji_unos=current_timestamp;
	RETURN NEW;
END $$;


ALTER FUNCTION public.poslednji_unos() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: clanovi; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub".clanovi (
    id_clana integer NOT NULL,
    ime character varying(45)[],
    prezime character varying(45)[],
    adresa character varying(45)[],
    br_telefona character varying(45)[],
    email character varying(45)[],
    korisnicko_ime character varying(45)[],
    lozinka character varying(45)[],
    datum_uclanjenja date,
    "status(aktivan/inaktivan)" character varying(45),
    "videoklub(radnja)_id_radnje" integer
);


ALTER TABLE "VideoKlub".clanovi OWNER TO postgres;

--
-- Name: evidencioni_karton; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub".evidencioni_karton (
    id_kartona integer NOT NULL,
    clanovi_id_clana integer,
    tarifa_id_tarife integer,
    filmovi_id_filma integer
);


ALTER TABLE "VideoKlub".evidencioni_karton OWNER TO postgres;

--
-- Name: filmovi; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub".filmovi (
    id_filma integer NOT NULL,
    naziv character varying(45)[],
    godina_izdanja integer,
    reziser character varying(45)[],
    ocena integer,
    kratak_opis character varying(100)[],
    jezik character varying(45)[],
    format character varying(5)[],
    duzina_trajanja character varying(45)[],
    "kategorija/zanr_id_kategorije" integer,
    poslednji_unos timestamp without time zone
);


ALTER TABLE "VideoKlub".filmovi OWNER TO postgres;

--
-- Name: kategorija/zanr; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub"."kategorija/zanr" (
    id_kategorije integer NOT NULL,
    naziv_kategorije character varying(45)[] NOT NULL
);


ALTER TABLE "VideoKlub"."kategorija/zanr" OWNER TO postgres;

--
-- Name: stanje_filmova; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub".stanje_filmova (
    id_stanja integer NOT NULL,
    videoklub_id_radnje integer,
    filmovi_id_filma integer,
    kolicina integer
);


ALTER TABLE "VideoKlub".stanje_filmova OWNER TO postgres;

--
-- Name: status_zaposlenih; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub".status_zaposlenih (
    id_statusa integer NOT NULL,
    status character varying(45)[] NOT NULL
);


ALTER TABLE "VideoKlub".status_zaposlenih OWNER TO postgres;

--
-- Name: tarife; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub".tarife (
    id_tarife integer NOT NULL,
    tarifa character varying(45)[] NOT NULL,
    rok_vracanja character varying(45)[] NOT NULL,
    cena_zamene character varying(45)[] NOT NULL
);


ALTER TABLE "VideoKlub".tarife OWNER TO postgres;

--
-- Name: videoklub; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub".videoklub (
    id_radnje integer NOT NULL,
    adresa_lokala text[],
    naziv_lokala text[]
);


ALTER TABLE "VideoKlub".videoklub OWNER TO postgres;

--
-- Name: zaposleni; Type: TABLE; Schema: VideoKlub; Owner: postgres
--

CREATE TABLE "VideoKlub".zaposleni (
    id_zaposleni integer NOT NULL,
    ime character varying(45)[] NOT NULL,
    prezime character varying(45)[] NOT NULL,
    adresa character varying(45)[] NOT NULL,
    email character varying(45)[],
    br_telefona character varying(45)[] NOT NULL,
    korisnicko_ime character varying(45)[] NOT NULL,
    lozinka character varying(45)[] NOT NULL,
    videoklub_id_radnje integer,
    status_zaposlenih_id_statusa integer
);


ALTER TABLE "VideoKlub".zaposleni OWNER TO postgres;

--
-- Name: kolicina_filmova; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.kolicina_filmova AS
 SELECT videoklub.naziv_lokala,
    filmovi.naziv,
    stanje_filmova.kolicina
   FROM (("VideoKlub".stanje_filmova
     JOIN "VideoKlub".videoklub ON ((videoklub.id_radnje = stanje_filmova.videoklub_id_radnje)))
     JOIN "VideoKlub".filmovi ON ((filmovi.id_filma = stanje_filmova.filmovi_id_filma)));


ALTER TABLE public.kolicina_filmova OWNER TO postgres;

--
-- Name: noviji_filmovi; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.noviji_filmovi AS
 SELECT filmovi.naziv,
    filmovi.godina_izdanja,
    filmovi.reziser,
    filmovi.ocena
   FROM "VideoKlub".filmovi
  WHERE (filmovi.godina_izdanja >= 2000);


ALTER TABLE public.noviji_filmovi OWNER TO postgres;

--
-- Name: zanr_filmova; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.zanr_filmova AS
 SELECT filmovi.naziv,
    filmovi.godina_izdanja,
    "kategorija/zanr".naziv_kategorije
   FROM ("VideoKlub".filmovi
     JOIN "VideoKlub"."kategorija/zanr" ON ((filmovi."kategorija/zanr_id_kategorije" = "kategorija/zanr".id_kategorije)));


ALTER TABLE public.zanr_filmova OWNER TO postgres;

--
-- Data for Name: clanovi; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2888.dat

--
-- Data for Name: evidencioni_karton; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2893.dat

--
-- Data for Name: filmovi; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2891.dat

--
-- Data for Name: kategorija/zanr; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2892.dat

--
-- Data for Name: stanje_filmova; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2895.dat

--
-- Data for Name: status_zaposlenih; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2890.dat

--
-- Data for Name: tarife; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2894.dat

--
-- Data for Name: videoklub; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2889.dat

--
-- Data for Name: zaposleni; Type: TABLE DATA; Schema: VideoKlub; Owner: postgres
--

\i $$PATH$$/2887.dat

--
-- Name: clanovi clanovi_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".clanovi
    ADD CONSTRAINT clanovi_pkey PRIMARY KEY (id_clana);


--
-- Name: evidencioni_karton evidencioni_karton_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".evidencioni_karton
    ADD CONSTRAINT evidencioni_karton_pkey PRIMARY KEY (id_kartona);


--
-- Name: filmovi filmovi_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".filmovi
    ADD CONSTRAINT filmovi_pkey PRIMARY KEY (id_filma);


--
-- Name: kategorija/zanr kategorija/zanr_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub"."kategorija/zanr"
    ADD CONSTRAINT "kategorija/zanr_pkey" PRIMARY KEY (id_kategorije);


--
-- Name: stanje_filmova stanje_filmova_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".stanje_filmova
    ADD CONSTRAINT stanje_filmova_pkey PRIMARY KEY (id_stanja);


--
-- Name: status_zaposlenih status_zaposlenih_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".status_zaposlenih
    ADD CONSTRAINT status_zaposlenih_pkey PRIMARY KEY (id_statusa);


--
-- Name: tarife tarife_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".tarife
    ADD CONSTRAINT tarife_pkey PRIMARY KEY (id_tarife);


--
-- Name: videoklub videoklub(radnja)_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".videoklub
    ADD CONSTRAINT "videoklub(radnja)_pkey" PRIMARY KEY (id_radnje);


--
-- Name: zaposleni zaposleni_pkey; Type: CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".zaposleni
    ADD CONSTRAINT zaposleni_pkey PRIMARY KEY (id_zaposleni);


--
-- Name: filmovi poslednji_unos; Type: TRIGGER; Schema: VideoKlub; Owner: postgres
--

CREATE TRIGGER poslednji_unos BEFORE UPDATE ON "VideoKlub".filmovi FOR EACH ROW EXECUTE PROCEDURE "VideoKlub".poslednji_unos();


--
-- Name: evidencioni_karton fk_clanovi; Type: FK CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".evidencioni_karton
    ADD CONSTRAINT fk_clanovi FOREIGN KEY (clanovi_id_clana) REFERENCES "VideoKlub".clanovi(id_clana);


--
-- Name: evidencioni_karton fk_filmovi; Type: FK CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".evidencioni_karton
    ADD CONSTRAINT fk_filmovi FOREIGN KEY (filmovi_id_filma) REFERENCES "VideoKlub".filmovi(id_filma);


--
-- Name: zaposleni fk_status_zaposlenih; Type: FK CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".zaposleni
    ADD CONSTRAINT fk_status_zaposlenih FOREIGN KEY (status_zaposlenih_id_statusa) REFERENCES "VideoKlub".status_zaposlenih(id_statusa);


--
-- Name: evidencioni_karton fk_tarifa; Type: FK CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".evidencioni_karton
    ADD CONSTRAINT fk_tarifa FOREIGN KEY (tarifa_id_tarife) REFERENCES "VideoKlub".tarife(id_tarife);


--
-- Name: stanje_filmova fk_videoklub; Type: FK CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".stanje_filmova
    ADD CONSTRAINT fk_videoklub FOREIGN KEY (videoklub_id_radnje) REFERENCES "VideoKlub".videoklub(id_radnje);


--
-- Name: clanovi fk_videoklub_(radnja); Type: FK CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".clanovi
    ADD CONSTRAINT "fk_videoklub_(radnja)" FOREIGN KEY ("videoklub(radnja)_id_radnje") REFERENCES "VideoKlub".videoklub(id_radnje);


--
-- Name: zaposleni fk_videoklub_(radnja); Type: FK CONSTRAINT; Schema: VideoKlub; Owner: postgres
--

ALTER TABLE ONLY "VideoKlub".zaposleni
    ADD CONSTRAINT "fk_videoklub_(radnja)" FOREIGN KEY (videoklub_id_radnje) REFERENCES "VideoKlub".videoklub(id_radnje);


--
-- PostgreSQL database dump complete
--

